package Lab11;

import java.util.*;
import java.time.*;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class DisplayTimer implements Runnable
{
	public void run()
	{
		try
		{
		while(true)
		{
			LocalDateTime now=LocalDateTime.now();
			System.out.println(now);
			Thread.sleep(10000);
		}
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args) 
	{
		Executor dt=Executors.newSingleThreadExecutor();
		Runnable task=new DisplayTimer();
		System.out.println("Showing the refresh time : ");
		dt.execute(task);
		
	}

}
