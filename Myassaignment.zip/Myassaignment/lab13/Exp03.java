package lab13;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Exp03 {
	public static void main(String[] args) {
		
		BiFunction<String ,String, Boolean>meth1=(str,str1)->
		{
			
			String abc="abhi";
			String xyz="12345";
			
			System.out.println("Enter the user name");
			Scanner sc=new Scanner(System.in);
			str=sc.nextLine();
			System.out.println("Enter the password");
			str1=sc.nextLine();
			
			if(str.equals(abc)&&str1.equals(xyz))
			{
				System.out.println("login successfully");
				return true;
			}
		
			System.out.println("login Failed");
			return false;
			
		};
		
		System.out.println(meth1.apply("str", "str1"));
	}

}
