package lab13;

import java.util.function.Function;

public class Exp02 {

	
	public static void main(String[] args) {
		
		Function< String, String>f1=(str)->
		{
			char c[]=str.toCharArray();
			StringBuilder sb=new StringBuilder();
			
			sb.append(str.charAt(0));
			
			for(int i=1;i<c.length;i++)
			{
				sb.append(" ");
				sb.append(c[i]);
			}
			
				return sb.toString();
			
			
		};
		System.out.println("String with spaces");
		System.out.println(f1.apply("abcd"));
	}
}
