package lab13;

import java.util.function.BiFunction;

public class Exp01 {

	public static void main(String[] args) {
		
		BiFunction<Integer ,Integer, Double>meth=(a,b)->Math.pow(a, b);
		
		
		System.out.println("a pow b is"+" "+meth.apply(2, 10));
		
	}
	
}
