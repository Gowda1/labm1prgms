package lab13;

public class Exp04 {

	private String name;
	private double price;
	
	public Exp04()
	{
		name="abc";
		price=20.0;
	}
	
	public Exp04(String name, double price) {
		
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Exp04 [name=" + name + ", price=" + price + "]";
	}
	
	
}
