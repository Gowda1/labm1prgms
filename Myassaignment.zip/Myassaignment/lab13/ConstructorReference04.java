package lab13;

import java.util.function.BiFunction;
import java.util.function.Supplier;

public class ConstructorReference04 {

	public static void main(String[] args) {
		
		Supplier<Exp04> s1=Exp04::new;//method reference
		
		System.out.println(s1.get());
		
		BiFunction<String, Integer, Exp04> f=Exp04::new;
		Exp04 ex=f.apply("xyz", 12);
		System.out.println(ex);
	}
}
