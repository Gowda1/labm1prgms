package com.pack5;

public class Book extends Witem{
	public Book()
	{
		System.out.println("**********");
	}

}
