package com.pack5;

public class MediaItem extends Item{
	public MediaItem()
	{
		System.out.println("--------------------");
	}

}
