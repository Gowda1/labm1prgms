package com.pack5;

public class Video {

	private String director;
	private String genre;
	private int Yearreleased;
	public String getDirector()
	{
		return director;
	}
	
	public void setDirector(String director)
	{
		this.director=director;
	}
	public String getGenre()
	{
		return genre;
	}
	public void setGenre(String genre)
	{
		this.genre=genre;
	}
	public int  getYearreleased()
	{
		return Yearreleased;
	}
	public void setYearreleased(int yearreleased)
	{
		Yearreleased= yearreleased;
	}
}
