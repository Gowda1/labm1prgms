package com.pack5;

public class All {

		public void director(String a) 
		{
			System.out.println("Name:"+a);
		}
		public void genre(String b) 
		{
			System.out.println("Genre:"+b);
		}	
		public void yearReleased(int i) 
		{
			System.out.println("Released year:"+i);
		}
		public void artist(String c) 
		{
			System.out.println("Name of the artist:"+c);
		}
		public static void main(String[] args) {
			Jbook i=new Jbook();
			i.setId(111111);
			i.setTitle("TR");
			i.setCopies(100);
			i.setAuthor("ram");
			i.setYearpublished(2019);
			System.out.println("id is:"+i.getId());
			System.out.println("Title:"+i.getTitle());
			System.out.println("No.of.Copies:"+i.getCopies());
			System.out.println("Author name:"+i.getAuthor());
			System.out.println("Published in year:"+i.getCopies());
			All a=new All();
			a.director("nan");
			a.yearReleased(2019);
			a.artist("nandan");
			a.genre("Albumm");
		}
		
		
}
