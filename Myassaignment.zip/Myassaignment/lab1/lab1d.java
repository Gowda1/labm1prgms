import java.util.Scanner;
public class Main
{
public static void main(String[] args)
{
Power p=new Power();
p.checkNumber(10);
}
}
class Power
{
public void checkNumber(int n)
{
int Pow=1;
boolean TorF=false;
if(n%2==0)
{
for(int i=1;i<=n/2;i++)
{
Pow*=2;
if(Pow==n)

{
TorF=true;
break;
}
else
{
TorF=false;
}
}
}
System.out.println(TorF);
}
}