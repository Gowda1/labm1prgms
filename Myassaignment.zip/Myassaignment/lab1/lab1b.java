import java.util.Scanner;
public class Main
{
public static void main(String[] args)
{
Difference d=new Difference();
d.calculateDifference(10);
}
}
class Difference
{
public void calculateDifference(int n)
{
int sumOfSquare=0,squareOfSum=0,diff=0,sum=0;
for(int i=1;i<=n;i++)
{
sumOfSquare+=i*i;
sum+=i;
}
squareOfSum=sum*sum;
diff=sumOfSquare-squareOfSum;
System.out.println(diff);
}
}