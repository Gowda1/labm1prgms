import java.util.Scanner;
public class Main
{
public static void main(String[] args)
{
CheckSequence c=new CheckSequence();
c.checkNumber(134468);
}
}
class CheckSequence
{
public void checkNumber(int n)
{
int bigNumber=10;
boolean TorF=false;
while(n>0)
{
int digit=n%10;
n=n/10;
if(digit<=bigNumber)
{
bigNumber=digit;
TorF=true;
}
else
{
TorF=false;
break;

}
}
System.out.println(TorF);
}
}