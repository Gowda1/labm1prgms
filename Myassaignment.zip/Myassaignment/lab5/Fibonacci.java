package com.pack7;

import java.util.Scanner;

public class Fibonacci {

	public static int fib(int n)
	{
		int n1=0,i,n2=1,n3=0;
		for( i=2;i<=n;i++) {
			n3=n1+n2;
			n1=n2;
			n2=n3;
			
		}
		return n3;
	}
	public static int recfib(int n)
	{
		if(n==2)
		{
			return 1;
		}
		
		else if(n==1)
		{
			return 1;
		}
		else
		{
			return recfib(n-1)+recfib(n-2);
			
		}}
		
		public static void main(String[] args) {
			
		System.out.println(" Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(" nth value of fibonacci series is "+"" +fib(n));
	
		System.out.println("  nth value of recursive fibonacci series is "+"" +fib(n));
		
		}
	}

