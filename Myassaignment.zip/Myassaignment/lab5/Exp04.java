package apak;

import java.util.Scanner;

public class Exp04 extends isValidate  {

	
	Exp04(String name) {
		super(name);
		
	}

	public static void main(String[] args) {
		
		System.out.println("Enter the first name");
		Scanner sc=new Scanner(System.in);
		String fname=sc.nextLine();
		System.out.println("Enter the last name");
		String lname=sc.nextLine();
		
		
		isvalid(fname,lname);
		
		sc.close();
		
		
		
	}
}
