package apak;

public class InvalidAge extends Exception {
	
	public String toString()
	{
		return "you are not allowed your age is below 15";
	}
	public static void age(int n)
	{
		try {
			
			if(n<15)
			{
				throw new CheckValidage();
			}
			
			else
			{
				System.out.println("welcom...!\nyour age is validated");
			}
		} catch (Exception e) {
			
			System.out.println(e);
		}
		
	}
	

}
