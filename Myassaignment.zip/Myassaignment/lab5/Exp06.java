package com.cg.eis.exception;

import java.util.Scanner;

public class Exp06 extends CheckSalary {
	
	public static void main(String[] args) {
		
		System.out.println("Enter The salary");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
	salary(n);
		
	}

}
