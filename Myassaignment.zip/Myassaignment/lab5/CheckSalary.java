package com.cg.eis.exception;

public class CheckSalary extends Exception 
{
	
	public String toString()
	{
		return "your salary is less than 3000. please enter valid salary..!";
	}
	public static void salary(int n)
	{
		
		try {
			
			if(n<3000)
				
			{
				throw new CheckSalary();
			}
			else
			{
				System.out.println("salary is "+n+" "+"Rs");
			}
			
		} catch (Exception e) {
			System.out.println(e);
			
		}
	}
	

}
