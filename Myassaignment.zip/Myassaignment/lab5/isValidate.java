package apak;


	public class isValidate extends Exception {
		
		
		isValidate(String name)
		{
			super(name);
		}
			public static void isvalid(String fname,String lname)
			{
				
				try {
					
					if(fname.isEmpty()||lname.isEmpty())
					{
						throw new isValidate("Invalid First name or Last name");
					}
					else
					{
						System.out.println("validate successfully...!");
					}
				} catch (Exception e) {
					
					System.out.println(e.getMessage());
					
				}
				
			}
		

	}


