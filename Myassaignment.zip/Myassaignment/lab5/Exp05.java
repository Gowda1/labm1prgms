package apak;

import java.util.Scanner;

public class Exp05 extends CheckValidage {
	
	public static void main(String[] args) {
		
		System.out.println("Enter The Age");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		age(n);
		
		
	}

}
