package com.pack6;
import java.util.*;

public class Traffic {
	

	
	public static void main(String[] args) 
	{
		System.out.println(" Enter one number:");
		

		System.out.println(" 1.RED");
		System.out.println(" 2.YELLOW");
		System.out.println(" 3.GREEN"+"");
		Scanner sc =new Scanner(System.in);
		int n= sc.nextInt();
		
			switch(n)
			{
			case 1:
			{
				System.out.println(" STOP:");
				break;
			}
			case 2:
			{
				System.out.println(" READY:");
				break;
			}
			case 3:
			{
				System.out.println(" GO:");
				break;
			}
		default:
		
		break;
	}

	}
}
