
public class Main
{
public static void main(String[] args)
{
String[] ar={"One","Two","Three","Four","Five"};
sortArray(ar);

}


public static void sortArray(String[] ar)
{
String temp;

for(int i=0;i<=ar.length;i++)
{
for(int j=i+1;j<ar.length;j++)
{

if((ar[i].compareTo(ar[j])>0))
{
temp=ar[i];
ar[i]=ar[j];
ar[j]=temp;
}
}
}
printArray(ar);
}
public static void printArray(String[] ar)
{
int loop=0;
if(loop%2==0)
loop=ar.length/2;
else
loop=(ar.length/2)+1;
for(int i=0;i<=ar.length;i++)
{
if(i<=loop)
System.out.println(ar[i].toUpperCase());
else
System.out.println(ar[i].toLowerCase());
}
}
}


