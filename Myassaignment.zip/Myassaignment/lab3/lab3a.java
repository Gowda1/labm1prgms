public class Main
{
public static void main(String[] args)
{
int[] ar={5,2,6,3,7};
getSecondSmallest(ar);

}


public static void getSecondSmallest(int[] ar)
{
int temp=0;

for(int i=0;i<=ar.length;i++)
{
for(int j=i+1;j<ar.length;j++)
{

if(ar[i]>ar[j])
{
temp=ar[i];
ar[i]=ar[j];
ar[j]=temp;
}
}
}
System.out.println(ar[1]);
}
}