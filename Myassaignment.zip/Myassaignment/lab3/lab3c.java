
public class Main
{
public static void main(String[] args)
{
int[] ar={6,2,7,1,9};
reverseArray(ar);

}


public static void sortArray(int[] ar)
{
int temp=0;

for(int i=0;i<ar.length;i++)
{
for(int j=i+1;j<ar.length;j++)
{

if(ar[i]>ar[j])
{
temp=ar[i];
ar[i]=ar[j];
ar[j]=temp;
}
}
}
for(int num:ar)
{
if(num!=ar[ar.length-1])
System.out.print(num+",");
else
System.out.print(num);
}
System.out.println();
}



public static void reverseArray(int[] ar)
{
int[] array=new int[ar.length];
int j=ar.length-1;
for(int i=0;i<ar.length;i++)
{
array[i]=ar[j];
j--;
}
for(int i:array)
{
System.out.print(i+"");
}
System.out.println();
sortArray(ar);
}
}