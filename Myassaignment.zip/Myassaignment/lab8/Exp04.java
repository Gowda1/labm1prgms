package lab8;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Exp04 {
	
	public static void checkInfo(String filename) throws IOException
	{
		
	File fi=new File(filename);
	
	System.out.println("filename"+"-"+fi.getName());
	
	if(fi.exists())
	{
		System.out.println("File is exist");
	}
	else
	{
		System.out.println("file does not exist");
	}
	
	//System.out.println("file path is "+fi.getAbsolutePath());
	System.out.println("file is Readable"+"-"+fi.canRead());
	System.out.println("file is Writable"+"-"+fi.canWrite());


	if(filename.endsWith(".jpeg")||filename.endsWith(".png")||filename.endsWith(".fl"))
	{
		System.out.println("file you entered is image file");
	}
	else if(filename.endsWith(".txt"))
			{
		System.out.println("file you entered is text file");
	}
	else if(filename.endsWith(".exe"))
	{
		System.out.println("file you entered is executable file");
	}
	else
	{
		System.out.println("unkown file name");
	}
	System.out.println("File Size is "+fi.length()+" bytes");
	
	
	}

	
	
	public static void main(String[] args) throws IOException {
		
		System.out.println("Enter the file name");
		Scanner sc=new Scanner(System.in);
		
		String filename=sc.nextLine();
		checkInfo(filename);
		
		
		
	}
}
