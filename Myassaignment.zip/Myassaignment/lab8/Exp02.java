package lab8;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Exp02 {
	
	public static void main(String[] args) {
	{
	
	try {
		
	
	int count = 1;
		FileReader fr=new FileReader("text8.txt");
		BufferedReader br=new BufferedReader(fr);
		
		
	   boolean eof=true;
		while(eof==true)
		{
			String s=br.readLine();
			if (s==null)
				eof=false;
			else
				System.out.println(count+"."+s);
			count++;
			
			
			
		}
		
	br.close();	
	} catch (Exception e) {
		
		e.printStackTrace();
	}
}

}


}