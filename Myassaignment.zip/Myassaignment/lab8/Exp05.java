package lab8;

import java.util.Arrays;
import java.util.Scanner;

public class Exp05 {

	public static boolean checkString(String str)
	{
		
		int n=str.length();
	    char[] c1=new char[n];
	   
		c1=str.toCharArray();
		
		Arrays.sort(c1);
	
		
		
		for(int i=0;i<n;i++)
		{
			if(c1[i]!=str.charAt(i))
			{
				return false;
			}
		}
		
		
		return true;
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Enter The String");
		
		Scanner sc=new Scanner(System.in);
	String str=	sc.next();
		
	boolean a=checkString(str);

	if(a==true)
	{
		System.out.println("Entered String is positive");
	}
	else
		System.out.println("Entered String is Negative");
	
		}
}
