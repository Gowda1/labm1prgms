package lab8;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;




public class Exp06 {
	
	public static void calDuration(int yy,int mm,int dd)
	{
		LocalDate date=LocalDate.now();
		LocalDate udate=LocalDate.of(yy, mm, dd);
		System.out.println("Current System Date:"+date);

		
		Period p=Period.between(udate, date);
		System.out.println("Duration is:"+"\n"+p.getDays()+" days "+p.getMonths()+" months "+p.getYears()+" years");
	
		
	}
	
	
	
	public static void main(String[] args) {
		
		System.out.println("Enter The Date From You Want to calculate days till current date");
		System.out.println("Enter the year");
		Scanner sc=new Scanner(System.in);
		int yy=sc.nextInt();
		
		System.out.println("Enter the month");
		Scanner sc1=new Scanner(System.in);
		int mm=sc1.nextInt();
		
		System.out.println("Enter the day");
		Scanner sc2=new Scanner(System.in);
		int dd=sc.nextInt();
		
	
		calDuration(yy,mm,dd);
	
	}

}
