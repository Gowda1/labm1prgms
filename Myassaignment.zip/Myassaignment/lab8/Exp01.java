package lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Exp01 {
	
	public static void main(String[] args) {
		
		
		System.out.println("Enter the Integer with space");
		Scanner sc=new Scanner(System.in);
		
		String str =sc.nextLine();
		token(str);
	}
	
	
		public static void token(String str)
		{
			int sum1=0;
		StringTokenizer st=new StringTokenizer(str, " ");
		
		while(st.hasMoreTokens())
		{
			String temp=st.nextToken();
			
			int n=Integer.parseInt(temp);
			System.out.println(n);
			
		 sum1=sum1+n;
		}
		System.out.println("The sum of each the integer is "+sum1);
		
		
		
		
		
	}

}
