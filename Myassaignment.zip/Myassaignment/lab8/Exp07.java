package lab8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Exp07 {

	public static boolean isValid(String name)
	{
		
		   String regx = "^*_job$";
		    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
		    Matcher matcher = pattern.matcher(name);
		    return matcher.find();
		
	}
	
	public static void main(String[] args)
	
	{
		
		System.out.println("Enter the user name");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		
		 if (isValid(name)) 
		 {  
			 System.out.println("Valid User name");  
	     } 
		 else 
		 	{  
	            System.out.println("Invalid User name");  
	        } 
		
	}
	
	
}
