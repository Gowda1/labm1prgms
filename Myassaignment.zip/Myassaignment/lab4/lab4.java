
public class Main
{
public static void main(String[] args)
{
sumOfCubes(123);

}


public static void sumOfCubes(int n)
{
int sum=0;
while(n>0)
{
int digit=n%10;
n=n/10;
sum+=(digit*digit*digit);
}
System.out.println(sum);
}
}
