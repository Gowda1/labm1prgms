package lab10;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyData
{
	public static void main(String []args)
	{
		File infile =new File("C:\Users\nandaac\Desktop\nanassaignment\lab10\\source.txt");
		File outfile =new File("output.txt");
		FileReader fr=null;
		FileWriter fw=null;
		try {
			fr=new FileReader(infile);
			fw=new FileWriter(outfile);
			int ch;
			int cnt=0;
			while((ch=fr.read())!=-1) {
				fw.write(ch);
				if(ch!=10) {
					cnt++;
				
				}
				if(cnt%10==0) {
					System.out.println("10 char copied");
					Thread.sleep(5000);
				}
				
			}
		}
		
			catch(IOException e) {
				System.out.println(e);
				System.exit(-1);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
			finally {
				try {
					System.out.println("File copied");
					fr.close();
					fw.close();
				}
				catch(IOException e) {
					
				}
			}
		}
	}
