package lab10;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Currency;
import java.util.Date;
import java.util.Timer;

public class Timer1 implements Runnable{

	@Override
	public void run() {	
		
	
		try {
			
			Date d=new Date();
			
			//	LocalTime ltime=LocalTime.now();
				SimpleDateFormat sd=new SimpleDateFormat("hh:mm:ss");
				String time=sd.format(d);
		       System.out.println("Time:"+time);
				
				
				Thread.sleep(10000);
				run();
			} 
		
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
	
		
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		Timer1 t1=new Timer1();
		
		Thread th=new Thread(t1);
		th.start();
	
		
		
		
		
		
	
		
	}

}
