package lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exp02 {

	
	
	public static HashMap fcount(char[] c)
	{
	
		HashMap<String, Integer>  hashmap=new HashMap<String, Integer>();
	for(int i=0;i<c.length;i++)
		{
		int count=0;
	
	 	for(int j=0;j<c.length;j++)

			{

			if(j<i&&c[j]==c[i])
				{
				break;
				}

			if(c[i]==c[j])
				{
				count++;
				}

			}
	 	
		if(count>0)
		{
		System.out.println(c[i]+" is"+count+" "+"times");
		String str=Character.toString(c[i]);
		hashmap.put(str,count);
		}

		
		
		}
	return hashmap;

		
		
	}
	public static void main(String[] args) {
		
	Scanner sc=new Scanner(System.in);
		
	System.out.println("enter the character ");
		
	char c[]=sc.next().toCharArray();
		
	System.out.println("the character and frequency is"+fcount(c));
	
		
		
	}
}
