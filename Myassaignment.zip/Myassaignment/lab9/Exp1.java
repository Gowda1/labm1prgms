package lab9;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Exp1 {
	
	
	public static List sortedMap(HashMap<String, Integer> hashmap)
	{
		
	ArrayList<Integer> arr=new ArrayList<Integer>();
	

	arr.addAll(hashmap.values());
	Collections.sort(arr);
	
	
	return arr;
		
	}
	
	public static void main(String[] args) {
		
		
HashMap<String, Integer>  hashmap=new HashMap<String, Integer>();
		
		hashmap.put("one", new Integer(10));
		hashmap.put("two", new Integer(2));
		hashmap.put("Three", new Integer(98));
		
		
		
		
		System.out.println("Arraylist sorted values are :"+sortedMap(hashmap));
		
	}

	
	
	
		
	}

