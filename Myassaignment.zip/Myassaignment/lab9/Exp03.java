package lab9;

import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Exp03 {
	
	public static HashMap calSqure(int[] a,int n)
	{
		int x;
		HashMap<Integer,Integer>  hashmap=new HashMap<Integer,Integer>();
		
		for(int i=0;i<n;i++)
		{
			x=a[i]*a[i];
			
			System.out.println(x);
			hashmap.put(a[i], x);
			
		}
		
	
		return hashmap;
		
	}

	public static void main(String[] args) {
		
		int a[]=new int[10];
		System.out.println("Enter the size of array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		System.out.println("Enter the  array");
		
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println("Array elements and its square is"+calSqure(a,n));
	}
}
